CPSC 481-04
Project 1 - A*
Team Name: TEMP
Intro: The algorithm used to develop this project is A*
Contents:
	assets - folder containing helper files for css and drawing
	cs-sketch-paint.js - javascript file containing the majority of code used to compute the a* function
	index-js-p5-jathp-5.html - index html file that contains lisp code that calls the javascript functions as well as some attempts at writing the code in lisp
	Jathp.js - javascript file containing helper functions for diplaying on canvas
	p5.js - javascript file that contains helper functions for displaying on canvas
	Project Algorithm Report.pdf - Required documentation describing the project
	README.txt - required documentation for defining many attributes of the project
	sprite-cells-28x28-a.png - image file that is used to display the path
External Requirements: None
Setup and Installation: 
	1. Extract the Zip file into any folder
	2. Double click or open index.html with a browser to display the projects output
Features: 
	Runs A star algorithm
	Missing: display path backtracking to start
Bugs: 
	logical error results in minor mis-steps of algorithm